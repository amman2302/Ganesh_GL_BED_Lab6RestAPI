package com.gl.collegefest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class CollegeFestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeFestApplication.class, args);
		System.out.println("Hi Main");
	}

}
